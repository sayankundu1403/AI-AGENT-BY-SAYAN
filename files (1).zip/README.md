# AI Chatbot Agent

A fully customizable AI chatbot powered by Claude, deployable on GitHub Pages + Render.

## Project structure

```
index.html   → frontend (deploy to GitHub Pages)
server.js    → backend proxy (deploy to Render)
package.json → server dependencies
```

---

## Step 1 — Deploy the backend to Render

The backend keeps your API key secret.

1. Push this repo to GitHub.
2. Go to [render.com](https://render.com) and sign up (free).
3. Click **New → Web Service** and connect your GitHub repo.
4. Set these:
   - **Build command**: `npm install`
   - **Start command**: `node server.js`
   - **Environment variable**: `ANTHROPIC_API_KEY` = your key from [console.anthropic.com](https://console.anthropic.com)
5. Click **Deploy**. Once live, copy your Render URL (e.g. `https://my-agent.onrender.com`).

---

## Step 2 — Update the frontend

Open `index.html` and find this line near the top of the `<script>` block:

```js
const PROXY_URL = "https://YOUR_RENDER_URL.onrender.com/chat";
```

Replace `YOUR_RENDER_URL` with your actual Render subdomain.

---

## Step 3 — Deploy the frontend to GitHub Pages

1. Go to your GitHub repo → **Settings → Pages**.
2. Under **Source**, select **Deploy from a branch** → `main` → `/ (root)`.
3. Save. Your site will be live at `https://YOUR_USERNAME.github.io/YOUR_REPO/`.

---

## Customization

Edit the system prompt and agent name right in the chat UI — no code changes needed. You can also add presets by editing the `presets` object in `index.html`.

## Getting an API key

Sign up at [console.anthropic.com](https://console.anthropic.com) → API Keys → Create Key.
